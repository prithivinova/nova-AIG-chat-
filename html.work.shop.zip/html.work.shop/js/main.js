! function() {
    "use strict";
    $(".search-trigger").on("click", function(e) {
        e.preventDefault(), $(".search-wrap").animate({
            opacity: "toggle"
        }, 500), $(".nav-search, #search-close").addClass("open")
    }), $(".search-close").on("click", function(e) {
        e.preventDefault(), $(".search-wrap").animate({
            opacity: "toggle"
        }, 500), $(".nav-search, #search-close").removeClass("open")
    }), $(document.body).on("click", function(e) {
        $(".search-wrap").fadeOut(200), $(".nav-search, #search-close").removeClass("open")
    }), $(".search-trigger, .main-search-input").on("click", function(e) {
        e.stopPropagation()
    }), $(".team-carousel").owlCarousel({
        items: 4,
        margin: 30,
        dots: !1,
        nav: !1,
        loop: !0,
        autoplay: !0,
        autoplayTimeout: 2e3,
        autoplayHoverPause: !0,
        responsive: {
            0: {
                items: 1
            },
            480: {
                items: 1
            },
            768: {
                items: 3
            },
            992: {
                items: 4
            }
        }
    }), $(".partners-carousel").owlCarousel({
        items: 6,
        margin: 60,
        dots: !1,
        nav: !1,
        loop: !0,
        autoplay: !0,
        autoplayTimeout: 2e3,
        autoplayHoverPause: !0,
        responsive: {
            0: {
                items: 1
            },
            480: {
                items: 2
            },
            768: {
                items: 3
            },
            992: {
                items: 6
            }
        }
    }), $(".team-carousel").owlCarousel({
        items: 4,
        margin: 30,
        dots: !1,
        nav: !1,
        loop: !0,
        autoplay: !0,
        autoplayTimeout: 2e3,
        autoplayHoverPause: !0,
        responsive: {
            0: {
                items: 1
            },
            480: {
                items: 1
            },
            768: {
                items: 3
            },
            992: {
                items: 4
            }
        }
    }), $(".project-gallery").owlCarousel({
        items: 4,
        margin: 30,
        dots: !1,
        nav: !0,
        navText: ["<i class='icon-arrow-left'></i>", "<i class='icon-arrow-right'></i>"],
        loop: !1,
        autoplay: !0,
        autoplayTimeout: 2e3,
        autoplayHoverPause: !0,
        responsive: {
            0: {
                items: 1
            },
            480: {
                items: 2
            },
            768: {
                items: 3
            },
            992: {
                items: 4
            }
        }
    }), $(".main-menu").sticky({
        topSpacing: 0,
        bottomSpacing: 5
    }), $(".video-btn").magnificPopup({
        type: "iframe",
        iframe: {
            markup: '<div class="mfp-iframe-scaler"><div class="mfp-close"></div><iframe class="mfp-iframe" frameborder="0" allowfullscreen></iframe></div>',
            patterns: {
                youtube: {
                    index: "youtube.com/",
                    id: "v=",
                    src: "http://www.youtube.com/embed/%id%?autoplay=1"
                }
            },
            srcAction: "iframe_src"
        }
    }), $(window).load(function() {
        $("#box,#hill").fadeOut(), $("#loader,.preloader").delay(350).fadeOut("slow"), $("body").delay(350).css({
            overflow: "visible"
        })
    })
}();